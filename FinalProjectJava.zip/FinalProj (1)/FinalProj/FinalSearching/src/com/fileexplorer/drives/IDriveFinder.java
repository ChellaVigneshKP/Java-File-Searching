package com.fileexplorer.drives;
import java.util.List;
public interface IDriveFinder {
	public List<String> findDrives();
}
