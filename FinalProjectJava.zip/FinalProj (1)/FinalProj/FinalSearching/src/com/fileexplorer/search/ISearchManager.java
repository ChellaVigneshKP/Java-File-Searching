package com.fileexplorer.search;
import java.util.List;
public interface ISearchManager {
	public List<String> search(String fileName ,  List<String> drives);
}
